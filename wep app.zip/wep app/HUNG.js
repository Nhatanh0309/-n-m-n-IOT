const express = require("express");
const app = express();

//setting view engine to ejs
app.set("view engine", "ejs");
app.use(express.static("public"));

app.get("/", (req, res) => {
  res.send("Chào mừng trang chủ");
});

app.get("/dang-nhap", (req, res) => {
    res.render("login");
});


app.get("/cambien", (req, res) => {
  res.render('cambien/index');
}); 

app.get("/edit", (req, res) => {
  res.render('cambien/edit');
});

app.get("/admin", (req, res) => {
    res.render("admin");
});

app.listen(4000, () => {
  console.log("Dang chay ở port 4000");
});
